<!DOCTYPE html>
<html>
<head>
  <meta charset="UTF-8">
  <title>ログイン</title>
</head>
<body>
  <h1>ログイン</h1>
  
  <form action="loginLoading.php" method="post">
    <label for="id">email:</label>
    <input type="text" id="email" name="email" required><br>
    
    <label for="password">パスワード:</label>
    <input type="password" id="password" name="password" required><br>
    
    <input type="submit" value="ログイン">
  </form>
</body>
</html>