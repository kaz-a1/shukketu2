<!DOCTYPE html>
<html>
<head>
  <meta charset="UTF-8">
  <title>Teacher Page</title>
</head>
<body>
  <h1>Teacher Page</h1>
  
  <form action="teacherInfo.php" method = "post">
    <label for="hour">何時間目:</label>
    <select id="hour" name="hour">
      <option value="1">1時間目</option>
      <option value="2">2時間目</option>
      <option value="3">3時間目</option>
      <option value="4">4時間目</option>
      <option value="5">5時間目</option>
      <option value="6">6時間目</option>
    </select><br>
    
    <label for="subjectID">教員IDを入力してください</label>
    <input type="teacherID" id="teacherID" name="teacherID" maxlength="6" required><br>
    
    <?php
    echo "<label for=\"subjectID\"　required>授業IDを入力してください</label>";
    $link = new PDO('mysql:host=localhost;dbname=shukketu', 'root', '');
    //教員IDの入力から取得したデータを代入(JS)
    $id = 1101;
    $stmt = $link->prepare(" select * from subject WHERE teacherID = :id;");
    $stmt->bindParam(':id', $id);
    $res = $stmt->execute();
    if($res){
        $subjectDate = $stmt->fetchAll(PDO::FETCH_ASSOC);
        echo("<select id=\"subjectID\" name=\"subjectID\">");
        foreach ($subjectDate as $subject) {
            echo '<option value="' . $subject['subjectID'] . '">' . "ID".$subject['subjectID'] .":".$subject['subjectName'] . '</option>';
        }
    }else{
        echo "接続に失敗";
    }    
    echo "</select><br>";
    ?>
    
    <input type="submit" value="起動">
  </form>
</body>
</html>
