<?php

try {
    $link = new PDO('mysql:host=localhost;dbname=shukketu', 'root', '');
    echo "接続成功";
    
    $email = $_POST['email'];
    $password = $_POST['password'];
    $henkou = array("@",".");
    $rep = str_replace($henkou,"",$email);
    $stmt = $link->prepare("SELECT * FROM teacherac WHERE email = :email AND pass = :password");
    $stmt->bindParam(':email', $rep);
    $stmt->bindParam(':password',$password);
    $res = $stmt->execute();
    echo $res;
    $data = $stmt->fetch(PDO::FETCH_ASSOC);
    if (var_dump($data)) {
        session_start();
        echo $date[pass];
        echo "<h2>ログインに成功しました</h2>";
        $_SESSION['teacherID'] = $data['teacherID'];
        $_SESSION['name'] = $data['name'];
    } else {
        echo "<form action=\"signin.php\" method=\"post\">";
        echo "<h2>メールアドレスまたはパスワードが違います</h2>";
        echo "<h2>新しくアカウントを作成</h2>";
        echo "<input type=\"submit\" value=\"アカウントを作成\">";
        echo "</form>";
    }
} catch (PDOException $e) {
    die('接続失敗！' . $e->getMessage());
}

?>
